package Version1;

/*
 * Author:	Patrick and Marco
 * Date:		5/14/2019
 * Class:	CSC 160 Combo
 * Assignment:	Final Project
 * 
 * This program ......
 */

public class PasswordProtector
{

	public static void main( String[ ] args )
	{
		
	}

}
